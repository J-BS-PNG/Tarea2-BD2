import mysql.connector as mariadb

# decodigo.com

# Module Imports
import sys

# Connect to MariaDB Platform
try:
    conn = mariadb.connect(
        user='test_user',
        password='1426',
        host='localhost',
        port='3306',
        database='tarea2_db'

    )
    

except mariadb.Error as e:
    print(f"Error connecting to MariaDB Platform: {e}")
    sys.exit(1)

# Get Cursor
cur = conn.cursor()

