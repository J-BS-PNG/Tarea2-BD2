porBuscar = str(input())

def filtrar():
    pass

def steamming():
    pass

def buscarCoincidencia():
    pass