from os import getrandom
from unittest import result
from Backend.connection import cur, conn

#SELECTS

def totalPaginas():
    resultado = []
    query = "SELECT COUNT(pagina.id_pagina) from pagina"
    cur.execute(query)

    for dato in cur:
        resultado.append(dato[0])
    print(resultado)
    return resultado

def top25():
    resultado = []
    query = """SELECT sum(pagina_palabra.cantPalabra) as total, palabra.nombre_palabra from palabra inner join pagina_palabra on palabra.id_palabra = pagina_palabra.id_palabra 
    group by palabra.nombre_palabra 
    Order by total desc
    limit 20"""
    cur.execute(query)

    for cantidad, palabra  in cur:
        print(cantidad)
        variable = ' '.join([palabra, str(cantidad)])
        resultado.append(variable)
    print(resultado)
    return resultado

def getPagsFromPals(palabras):
    links = []
    for palabra in palabras:
        links += getPagFromPal(palabra)
    print("\n\n\n")
    print("*"*30)
    print(links)    
    print("*"*30)
    print("\n\n\n")
    
    return links

def getPagFromPal(palabra):
    resultado = []
    query = """SELECT url_pagina from pagina 
    inner join pagina_palabra on pagina.id_pagina = pagina_palabra.id_pagina 
    inner join palabra on palabra.id_palabra = pagina_palabra.id_palabra 
    WHERE nombre_palabra = %s"""
    data = (palabra,)
    cur.execute(query, data)

    for dato in cur:
        resultado.append(dato[0])

    return resultado

def getPalabraId(palabra): #Funcion que devuelve id del url ingresado
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT id_palabra from palabra where nombre_palabra =%s"
    data = (palabra,)
    cur.execute(query, data)
    for id_palabra in cur:
        resultado.append(id_palabra[0])

    return resultado

def getCanPalabra(urlid):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT cantPalabra from  pagina_palabra where id_pagina =%s"
    data = (urlid,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getPorcentajePalabraPagina(urlid):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT porcentajePalabra from  pagina_palabra where id_pagina =%s"
    data = (urlid,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getPorcentajePalabraTag(palabraid):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT porcentajePalabraTag from  tag_palabra where id_pagina =%s"
    data = (palabraid,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getEstadisticaId(urlid): #Funcion que devuelve id de las estadisticas del url ingresado
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT id_estadistica from  estadisticaPagina where id_pagina =%s"
    data = (urlid,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getCanTitulo(idurl):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT cantTitulo from estadisticaPagina where id_pagina =%s"
    data = (idurl,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getCanPalabrasTitulo(idurl):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT cantPalabrasTitulos from estadisticaPagina where id_pagina =%s"
    data = (idurl,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getCanPalabrasSubtitulo(idurl):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT cantPalabrasSubtitulos from estadisticaPagina where id_pagina =%s"
    data = (idurl,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getCanPalabrasGeneral(idurl):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT cantPalabrasGeneral from estadisticaPagina where id_pagina =%s"
    data = (idurl,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getCanReferencias(idurl):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT cantReferencia from estadisticaPagina where id_pagina =%s"
    data = (idurl,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getCanUsoReferencias(idurl):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT cantUsoRef from estadisticaPagina where id_pagina =%s"
    data = (idurl,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getCanAlt(idurl):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT cantAlt from estadisticaPagina where id_pagina =%s"
    data = (idurl,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getCanAltDiferentes(idurl):
    #En caso de que no exista retorna una lista vacia
    resultado = []
    query = "SELECT cantPalabrasAlt from estadisticaPagina where id_pagina =%s"
    data = (idurl,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])

    return resultado

def getUrlId(url): #Funcion que devuelve id del url ingresado
    resultado = []
    #En caso de que no exista retorna una lista vacia
    query = "SELECT id_pagina from pagina where url_pagina =%s"
    data = (url,)
    cur.execute(query, data)
    for id_pagina in cur:
        resultado.append(id_pagina[0])
    return resultado

def getTagId(tag): #Funcion que devuelve id del url ingresado
    resultado = []
    #En caso de que no exista retorna una lista vacia
    query = "SELECT id_tag from tag where nombre_tag =%s"
    data = (tag,)
    cur.execute(query, data)
    for id_tag in cur:
        resultado.append(id_tag[0])
    return resultado

def getRelacionUrlPagId(urlid, pagid):
    #id_pagina - id_palabra
    resultado = []
    #En caso de que no exista retorna una lista vacia
    query = "SELECT id_pagina, id_palabra from pagina_palabra where id_pagina =%s and id_palabra=%s"
    data = (urlid,pagid,)
    cur.execute(query, data)
    
    for (dato) in cur:
        resultado.append(dato[0])
        resultado.append(dato[1])
     
    return resultado

def getRelacionTagPagId(tagid, pagid):
    #id_tag - id_palabra
    resultado = []
    #En caso de que no exista retorna una lista vacia
    query = "SELECT id_tag, id_palabra from tag_palabra where id_tag =%s and id_palabra=%s"
    data = (tagid,pagid,)
    cur.execute(query, data)
    
    for (dato) in cur:
        resultado.append(dato[0])
        resultado.append(dato[1])
     
    return resultado

#INSERTS

def createEstadisticas(dato):
    query = "INSERT INTO estadisticaPagina (id_pagina) VALUES (%s)"
    data = (dato,)
    cur.execute(query, data)
    conn.commit()
    #print("Estadistica")

def insertCanTitulo(dato, ide):
    query = "UPDATE estadisticaPagina SET cantTitulo = (%s) where id_pagina = %s"
    data = (dato, ide,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertCanPalabrasTitulo(dato, ide):
    query = "UPDATE estadisticaPagina SET cantPalabrasTitulos = (%s) where id_pagina = %s"
    data = (dato, ide,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertPorcentajePalabraTag(dato, idp):
    query = "UPDATE tag_palabra SET porcentajePalabraTag = (%s) where id_palabra = %s"
    data = (dato, idp,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertCantPalabraPag(dato, idp, idpag):
    query = "UPDATE pagina_palabra SET cantPalabra = (%s) where id_palabra = %s and id_pagina = %s"
    data = (dato, idp, idpag,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertPorcentajetPalabraPag(dato, idp, idpag):
    query = "UPDATE pagina_palabra SET porcentajePalabra = (%s) where id_palabra = %s and id_pagina = %s"
    data = (dato, idp, idpag,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")


def insertCanPalabrasSubtitulo(dato, ide):
    query = "UPDATE estadisticaPagina SET cantPalabrasSubtitulos = (%s) where id_pagina = %s"
    data = (dato, ide,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertCanPalabrasGeneral(dato, ide):
    query = "UPDATE estadisticaPagina SET cantPalabrasGeneral = (%s) where id_pagina = %s"
    data = (dato, ide,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertCanReferencias(dato, ide):
    query = "UPDATE estadisticaPagina SET cantReferencia = (%s) where id_pagina = %s"
    data = (dato, ide,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertCanUsoReferencias(dato, ide):
    query = "UPDATE estadisticaPagina SET cantUsoRef = (%s) where id_pagina = %s"
    data = (dato, ide,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertCanAlt(dato, ide):
    query = "UPDATE estadisticaPagina SET cantAlt = (%s) where id_pagina = %s"
    data = (dato, ide,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertCanAltDiferentes(dato, ide):
    query = "UPDATE estadisticaPagina SET cantPalabrasAlt = (%s) where id_pagina = %s"
    data = (dato, ide,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertarPalabra(nombre):
    try:
        query = "INSERT INTO palabra (nombre_palabra) VALUES (%s)"
        data = (nombre,)
        cur.execute(query, data)
        conn.commit()
        #print("Palabra agregada")
    except:
        pass


def insertarUrl(url):
    query = "INSERT INTO pagina (url_pagina) VALUES (%s)"
    data = (url,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertarTag(tag):
    query = "INSERT INTO tag (nombre_tag) VALUES (%s)"
    data = (tag,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertarRelacionUrlPal(url_id, palabra_id):
    query = "INSERT INTO pagina_palabra (id_pagina, id_palabra) VALUES (%s, %s)"
    data = (url_id, palabra_id,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")

def insertarRelacionTagPal(tag_id, palabra_id):
    query = "INSERT INTO tag_palabra (id_tag, id_palabra) VALUES (%s, %s)"
    data = (tag_id, palabra_id,)
    cur.execute(query, data)
    conn.commit()
    #print("Palabra agregada")
