
from requests import get
from queries import *

def main():
    #Abrir archivo de estadisticas de palabra y tags
    f = open('Tags.txt', "r")
    for line in f: 
        linea = line.split()
        #print(linea[0])

        #toma la palabra del documetno
        palabra = linea[0]

        existePalabra = getPalabraId(palabra) #retorna una lista con el id de la palabra
        if len(existePalabra) == 0: #si la lista esta vacia la palabra no existe en la base de datos
            insertarPalabra(palabra) #inserta la palabra

        #Determina si se va a procesar url o tags
        if linea[2] == '1': #Se va a procesar el tag
            #toma el url
            url = linea[1]
            existeUrl = getUrlId(url)
            if len(existeUrl) == 0:
                insertarUrl(url)

            cantPalabras = linea[3]
            porcentajePalabras = linea[4]

            #ingresa la relacion url - palabra
            urlid = getUrlId(url)
            palabraid = getPalabraId(palabra)
            existeRelacion = getRelacionUrlPagId(urlid[0], palabraid[0])
            if len(existeRelacion) == 0:
                insertarRelacionUrlPal(int(urlid[0]), int(palabraid[0]))

            insertPorcentajetPalabraPag(porcentajePalabras ,palabraid[0],  urlid[0])
            insertCantPalabraPag(cantPalabras, palabraid[0],  urlid[0])
    

        if linea[2] == '2': #se va a p
            #toma el tag
            tag = linea[1]
            print
            existeTag = getTagId(tag)
            if len(existeTag) == 0:
                insertarTag(tag)

            porcentajePalabra = linea[3]
            
            #Ingresa la relacion tag - palabra
            tagid = getTagId(tag)
            palabraid =getPalabraId(palabra)
            existeRelacion = getRelacionTagPagId(tagid[0], palabraid[0])
            if len(existeRelacion) == 0:
                insertarRelacionTagPal(tagid[0], palabraid[0])
            
            insertPorcentajePalabraTag(porcentajePalabra, palabraid[0])

        
    f.close()
    
    #Abrir archivo estadisticas de pagina
    f = open('Paginas', "r")
    for linea in f:
        linea = linea.split()
        url = linea[0]
        problema = linea [1]
        cantidad = linea[2]
        urlid = getUrlId(url)
        estadisticaExists = getEstadisticaId(urlid[0])
        if len(estadisticaExists) == 0:
            createEstadisticas(urlid[0])
        

        if problema == '1':
            #cantidad de titulos
            insertCanTitulo(cantidad, urlid[0])
        if problema == '2':
            #palabras diferenres por titulo
            insertCanPalabrasTitulo(cantidad, urlid[0])

        if problema == '3':
            #palabras diferentes por subtitulos
            insertCanPalabrasSubtitulo(cantidad, urlid[0])

        if problema == '4':
            #palabras diferentes en la pagina
            insertCanPalabrasGeneral(cantidad, urlid[0])

        if problema =='5':
            #cantidad de referencias
            insertCanReferencias(cantidad,  urlid[0])

        if problema == '6':
            #cantidad de uso de referencias
            insertCanUsoReferencias(cantidad,  urlid[0])

        if problema == '7':
            #cantidad imagenes con alt
            insertCanAlt(cantidad,  urlid[0])

        if problema == '8':
            #palabras diferentes alt con steming
            insertCanAltDiferentes(cantidad,  urlid[0])
    f.close()

main()