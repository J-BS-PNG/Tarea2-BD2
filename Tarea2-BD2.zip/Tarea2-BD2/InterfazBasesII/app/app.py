from flask import Flask, render_template, request
import stemming
from Backend.queries import *

app = Flask(__name__)
@app.route('/')
def index():
    cursos = ['1', '2', '3', '4', '5', '6']
    
    data = {
        'totalPagina' : totalPaginas(),
        'top25': top25()
    }
    return render_template('homePage.html', data = data)

@app.route('/buscadorDePalabras')
def buscadorDePalabras():
    data = {
            'cursos' : '',
            'resultsCant' : 0
        }
    return render_template('busqueda.html', data = data)
@app.route('/buscarPorPalabra', methods=['POST','GET'])

def buscarPorPalabra():
    print("\n"*10)
    print("entra a busqueda")
    output = request.form.to_dict()
    texto = output["q"]
    print(texto)
    if texto != '':
        listaPalabras = stemming.Indice().indexar(texto)
        print(listaPalabras)
        datos = getPagsFromPals(listaPalabras)
        data = {
            'cursos' : datos,
            'resultsCant' : len(datos)
        }
        return render_template('busqueda.html', data = data)
    else:
        data = {
            'cursos' : '',
            'resultsCant' : 0
        }
        return render_template('busqueda.html', data = data)


if __name__ == '__main__':
    app.run(debug = True , port = 5500)
    