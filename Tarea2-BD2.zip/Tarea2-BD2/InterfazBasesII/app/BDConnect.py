import mysql.connector as mariadb
from queries import *

def Estadisticas():
    print("Entra")
    mariadb_conexion = mariadb.connect(host='localhost', port='3306',
                                    user='root', password='1234', database='test_db')
    cursor = mariadb_conexion.cursor()
    try:
        cursor.execute("SELECT id, detalle, link FROM Prueba")
        datos = []
        for id_usuario, detalle, link in cursor:
            datos += [[id_usuario,detalle, link]]
        print(datos)
        return datos

    except mariadb.Error as error:
        print("Error: {}".format(error))
    mariadb_conexion.close()

def getLinks(listaPalabras):
    links = []
    for palabra in listaPalabras:
        links += linksPorPalabra(palabra)
    print("\n\n\n")
    print("*"*30)
    print(links)    
    print("*"*30)
    print("\n\n\n")
    
    return links

def linksPorPalabra(palabra):
    print("Entra")
    mariadb_conexion = mariadb.connect(host='localhost', port='3306',
                                    user='root', password='1234', database='test_db')
    cursor = mariadb_conexion.cursor()
    try:
        cursor.execute("SELECT id, detalle, link FROM Prueba")
        datos = []
        for link in cursor:
            datos += [link]
        print(datos)
        return datos

    except mariadb.Error as error:
        print("Error: {}".format(error))
    mariadb_conexion.close()