#!/usr/bin/python
# coding=utf-8
import sys

"""
"""

# Por cada medida calculamos los pares <anyo, temp>

for linea in sys.stdin:
  linea = eval(linea)
  url = linea['url']
  tag = ""
  listaP = []
  for dic in linea:
    if not 'url' in dic and not 'reference' in dic and not'images' in dic:
        if 'title' == dic:
            tag = "h2"
            listaP = linea[dic].replace('-', '').split(' ')
        elif 'subtitle' == dic:
            tag = "h3"
            listaP = linea[dic].replace('-', '').split(' ')
        elif 'content' == dic:
            tag = "p"
            listaP = linea[dic].split(' ') 
        elif ('alt' == dic):
            tag = "alt"
            listaP = linea[dic].replace('-', '').split(' ') 
        for palabra in listaP:
                if palabra != '':
                    print("%s\t%s\t%s" %(url, tag, palabra))