#!/usr/bin/python
# coding=utf-8
import sys
from weakref import ref

"""
Reducer de MaxTemp
Obtenido de http://exponentis.es/
"""

#Punto c y d

'''
PROBLEMAS
1 - Conteo de titulos
2 - Palabras distintas(con stemming) de titulos 
3 - Palabras distintas(con stemming) subtitulos
4 - Palabras distintas(con stemming) la pagina
5 - Cuántas de las referencias tienen links 
6 - Cuántas veces se usa cada referencia en el texto
7 - Cuántas imágenes tienen Alt
8 - usando Stemming cuantas hay diferentes
9 - ¿Cuáles son las palabras más columnas en la página y si son estas partes del títuloo no?
10 - En cuáles páginas aparece y cuantas veces
11 - Qué porcentaje representa esa palabra del total de palabras distinas de la página
12 - En cuáles tags aparece y en qué porcentaje en cada tag

'''
problema1= ''
problema2= ''
problema3= ''
problema4= ''
problema5= ''
problema6= ''
problema7= ''
problema8= ''

for linea in sys.stdin:
    url, tag, palabras = linea.replace('\n', '').split('\t',2)
    listaP = palabras
    contador = 0
    if 'h2' == tag:
        problema1 = listaP.split('-')
        contador = len(problema1)
        print("%s\t%s\t%i" % (url, '1',contador))
        problema2 = listaP.replace('-', '').split(' ')
        contador = len(set(problema2))
        print("%s\t%s\t%i" % (url, '2',contador))
    
    if 'h3' == tag:
        problema3 = listaP.replace('-', '').split(' ')
        contador = len(set(problema2))
        print("%s\t%s\t%i" % (url, '3',contador))
    
    if 'p' == tag:
        problema4 = listaP.split(' ')
        problema4.extend(problema2)
        problema4.extend(problema3)
        contador = len(set(problema4))
        print("%s\t%s\t%i" % (url, '4',contador))
        problema2 = []
        problema3 = []
        problema4 = []
    
    if 'reference' == tag:
        problema5 = [ref for ref in listaP.split(' ') if 'http' in ref]
        contador = len(problema5)
        print("%s\t%s\t%i" % (url, '5',contador))
        problema6 = [ref for ref in listaP.split(' ') if 'cite' in ref]

        contador = len(problema6)
        print("%s\t%s\t%i" % (url, '6',contador))

    if 'alt' == tag:
        problema7 = listaP.split('-')
        contador = len(problema7)
        print("%s\t%s\t%i" % (url, '7',contador))
        problema8 = set(listaP.replace('-', '').split(' '))
        if '' in problema8:
            problema8.remove('')
        contador = len(problema8)
        print("%s\t%s\t%i" % (url, '8',contador))
