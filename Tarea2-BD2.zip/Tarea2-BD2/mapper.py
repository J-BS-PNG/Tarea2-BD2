#!/usr/bin/python
# coding=utf-8
import sys

"""
"""

# Por cada medida calculamos los pares <anyo, temp>

for linea in sys.stdin:
  linea = eval(linea)
  url = linea['url']
  tag = ""
  listaP = []
  for dic in linea:
    if not 'url' in dic :
        if 'title' == dic:
            tag = "h2"
        elif 'subtitle' == dic:
            tag = "h3"
        elif 'content' == dic:
            tag = "p"
        elif ('images' == dic):
            tag = "img"
        elif ('alt' == dic):
            tag = "alt" 
        elif ('references' == dic):
            tag = "reference"
        listaP = linea[dic]
        print("%s\t%s\t%s" %(url, tag, listaP))