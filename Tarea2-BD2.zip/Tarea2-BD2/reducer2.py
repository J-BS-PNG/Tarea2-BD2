#!/usr/bin/python
#coding=utf-8
import sys
from tokenize import Double

"""
Reducer de MaxTemp
Obtenido de http://exponentis.es/
"""

#Punto c y d

'''
PROBLEMAS
1- páginas aparece y cuantas veces y porcentaje de esa palabra en esa pagina
2- En cuáles tags aparece y en qué porcentaje en cada tag
'''

dicPalabra = {} 
dicPaginaPalabra={}
dicTag={}
dicTagPalabra={}
datoTemporal=''
valor = 0
cantidadPalabras=0
dicTemporal={}

for linea in sys.stdin:
    url, tag, palabra = linea.replace('\n', '').split('\t',2)
    contador = 0
    if palabra in dicPalabra:
        datoTemporal = dicPalabra[palabra]
        if url in datoTemporal:
            valor = datoTemporal[url] + 1
            datoTemporal.update({url:valor})           
        else:
            datoTemporal[url] = 1
    else:
        dicPalabra[palabra] = {url: 1}

    if url in dicPaginaPalabra:
        valor = dicPaginaPalabra[url]
        valor.add(palabra)
        dicPaginaPalabra.update({url: valor})
    else:
        dicPaginaPalabra[url] = {palabra}
    
    if palabra in dicTag:
        datoTemporal = dicTag[palabra]
        if tag in datoTemporal:
            valor = datoTemporal[tag] + 1
            datoTemporal.update({tag : valor})           
        else:
            datoTemporal[tag] = 1
    else:
        dicTag[palabra] = {tag: 1}

    if tag in dicTagPalabra:
        valor = dicTagPalabra[tag]
        valor.add(palabra)
        dicTagPalabra.update({tag: valor})
    else:
        dicTagPalabra[tag] = {palabra}

valor = 0
porcentaje = 0


for palabra in dicPalabra:
    dicTemporal = dicPalabra[palabra]
    for mUrl in dicTemporal:
        valor = float(dicTemporal[mUrl])
        porcentaje = valor/float(len(dicPaginaPalabra[mUrl]))
        print("%s\t%s\t%i\t%i\t%f" % (palabra,mUrl,1,valor,porcentaje))


for palabra in dicTag:
    dicTemporal = dicTag[palabra]
    for mTag in dicTemporal:
        valor = float(dicTemporal[mTag])
        porcentaje = valor/float(len(dicTagPalabra[mTag]))
        print("%s\t%s\t%i\t%f" % (palabra,mTag,2,porcentaje))

